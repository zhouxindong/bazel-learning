#pragma once

#include <string>

std::string hello_world();
