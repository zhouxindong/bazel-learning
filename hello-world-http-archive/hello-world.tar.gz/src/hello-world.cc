#include "include/hello-world.h"

std::string hello_world() { return "Hello, world!"; }
